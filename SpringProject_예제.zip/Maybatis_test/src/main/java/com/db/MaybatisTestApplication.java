package com.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaybatisTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaybatisTestApplication.class, args);
	}

}
