package board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardSpringProjectApplication.class, args);
	}

}
